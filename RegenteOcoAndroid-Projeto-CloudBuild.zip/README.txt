O REGENTE OCO - PROJETO ANDROID

Este projeto empacota o jogo HTML em um aplicativo Android (WebView).
O jogo fica dentro do aplicativo; não precisa abrir o HTML no navegador.

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Extraia a pasta RegenteOcoAndroid.zip.
3. No Android Studio, escolha Open e selecione a pasta RegenteOcoAndroid.
4. Aguarde o Gradle sincronizar e baixar os componentes necessários.
5. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
6. Ao terminar, clique em locate para encontrar o APK gerado.

CONFIGURAÇÃO
- Orientação: paisagem (horizontal).
- Tela cheia e navegação imersiva.
- JavaScript habilitado para o jogo.
- O HTML é carregado localmente, sem depender de hospedagem.

OBSERVAÇÃO
O projeto foi preparado, mas não foi compilado/testado em Android SDK neste ambiente.
